<h3 class="element-invisible">Lot Categories</h3>
<ul class="catnav">
    <li><a href="index.php?content=gents">Gents</a></li>	
    <li><a href="index.php?content=sporting">Sporting</a></li>	
    <li><a href="index.php?content=women">Women</a></li>
</ul>
