<div class="content">
    <h1>Product Category: Sporting</h1>

    <ul class="ulfancy">

        <li class="row0">					
            <div class="list-photo"><a href="images/skirted-bathing-1-254.jpg">
                    <img src="images/thumbnails/skirted-bathing-1-254.jpg"  alt="" /></a>
            </div>
            <div class="list-description">
                <h2>Ladies Bathing Costume, Shoes &amp; Floats, C. 1900</h2>
                <p>Marine blue lightweight wool, white sailor collar &amp; trim, button-on skirt, 
                    labeled "Arnold Constable &amp; Co. New York", B 34", W 25", L 40"; 1 pair black cotton 
                    knit thigh-high canvas sole bathing shoes &amp; set of "Aybad's Water Wings Patented 
                    May 7, 1901", excellent. </p>
                <p><strong>Lot:</strong> #4 
                    <strong>Price:</strong> $510.00</p>
            </div>
            <div class="clearfloat"></div>
        </li>

        <li class="row1">				
            <div class="list-photo"><a href="images/swimsuit-striped-9-265.jpg">
                    <img src="images/thumbnails/swimsuit-striped-9-265.jpg"  alt="" /></a>
            </div>
            <div class="list-description">
                <h2>Colorful Striped Wool Bathing Suit, C. 1910</h2>
                <p>Gent's 1-piece machine knit suit in red, green, black &amp; cream, 3 buttons each shoulder,
                    DLM, Ch 35", W 32.5", L 43", (minor mends, 1 dime size hole in back) good. </p>
                <p><strong>Lot:</strong> #5 
                    <strong>Price:</strong> $1,380.00</p>
            </div>			
            <div class="clearfloat"></div>
        </li>

        <li class="row0">					
            <div class="list-photo"><a href="images/frontier-10-549.jpg">
                    <img src="images/thumbnails/frontier-10-549.jpg"  alt="" /></a>
            </div>
            <div class="list-description">
                <h2>Frontier Beaded Jacket &amp; Chaps, C. 1920</h2>
                <p>Caramel deerskin leather w/ large glass beads in green &amp; white, Jacket: Chest 42", W 39", L 34",
                    Chap's inseam 29", prob. made by Mohawks for Wild West shows or as fraternal costume for Improved
                    Order of Red Men, (leather dry, bead loss) good. </p>
                <p><strong>Lot:</strong> #6 
                    <strong>Price:</strong> $258.75</p>
            </div>
            <div class="clearfloat"></div>
        </li>

    </ul>
</div><!-- end content -->