<?php
/**
 * home.php
 * content for the about page
 * @version 1.2 2018-04-16
 * @package Smith Side Auction
 * @copyright (c) 2018, Tung Pham IPD12
 * @license GNU Generl Public License
 * @since Release version 1.0
 */
?>
<h1>Next Auction September 22nd</h1>
<p>Join us for our next auction of historic clothing
to be held at the St. Paul's Auditorium in NYC on September 22nd at 1 o'clock.</p>

<p>Lots can be viewed the prior day from 4pm until 7pm and again on Thursday morning from
10am to noon.</p>


