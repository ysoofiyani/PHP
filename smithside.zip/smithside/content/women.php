<div class="content">
    <h1>Product Category: Women</h1>

    <ul class="ulfancy">

        <li class="row0">
            <div class="list-photo"><a href="images/gown-victorian-8-173.jpg">
                    <img src="images/thumbnails/gown-victorian-8-173.jpg"  alt="" /></a>
            </div>
            <div class="list-description">
                <h2>Printed &amp; Voided Velvet Evening Gown, 1850s</h2>
                <p>Chocolate brown silk faille with border design of brown and cream roses, uncut and voided
                    velvet printed in shades of brown and cream, full skirt in two tiers, back brass hook &amp; eye
                    closure, glazed linen bodice lining, (seams at waistline weak, minor stains) excellent. </p>
                <p><strong>Lot:</strong> #7 
                    <strong>Price:</strong> $13,800.00</p>
            </div>
            <div class="clearfloat"></div>
        </li>

        <li class="row1">					
            <div class="list-photo"><a href="images/dior-10-2.jpg">
                    <img src="images/thumbnails/dior-10-2.jpg"  alt="" /></a>
            </div>
            <div class="list-description">
                <h2>Dior Couture Wool Cocktail Dress, 1948</h2>
                <p>Unlabeled black melton wool 3 piece ensemble, c/o tulip shape skirt w/ projecting side panel,
                    strapless bodice w/ built-in corset, &amp; face-framing off-the-shoulder shrug, B 36", W 27", H 42",
                    center front bodice L 9.75", skirt L 31", excellent. </p>
                <p><strong>Lot:</strong> #8 
                    <strong>Price:</strong> $40,250.00</p>
            </div>
            <div class="clearfloat"></div>
        </li>

        <li class="row0">				
            <div class="list-photo"><a href="images/cardin-5-740.jpg">
                    <img src="images/thumbnails/cardin-5-740.jpg"  alt="" /></a>
            </div>
            <div class="list-description">
                <h2>Pierre Cardin For Mia Farrow Dress, 1967</h2>
                <p>Made exclusively for Mia Farrow in her first starring film role, 1968's "A Dandy In Aspic", white wool
                    woven in tiny honey-comb pattern, graduated accordian pleats from collar to hem, circular padded roll
                    collar w/ CF snap, white China silk lining. excellent. </p>
                <p><strong>Lot:</strong> #9 
                    <strong>Price:</strong> $19,550.00</p>
            </div>
            <div class="clearfloat"></div>
        </li>
    </ul>
</div><!-- end content -->